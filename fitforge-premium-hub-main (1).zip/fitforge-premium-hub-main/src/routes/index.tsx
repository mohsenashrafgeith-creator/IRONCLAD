import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  Dumbbell,
  Flame,
  Heart,
  Instagram,
  Menu,
  Quote,
  Twitter,
  Youtube,
  Zap,
} from "lucide-react";
import { toast, Toaster } from "sonner";

import hero from "@/assets/hero.jpg";
import w1 from "@/assets/workout-1.jpg";
import w2 from "@/assets/workout-2.jpg";
import w3 from "@/assets/workout-3.jpg";
import w4 from "@/assets/workout-4.jpg";
import w5 from "@/assets/workout-5.jpg";
import w6 from "@/assets/workout-6.jpg";
import t1 from "@/assets/transform-1.jpg";
import t2 from "@/assets/transform-2.jpg";
import t3 from "@/assets/transform-3.jpg";
import b1 from "@/assets/blog-1.jpg";
import b2 from "@/assets/blog-2.jpg";
import b3 from "@/assets/blog-3.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "IRONCLAD — Premium Fitness & Performance Club" },
      {
        name: "description",
        content:
          "Train without compromise. Memberships, BMI calculator, transformations, workouts and a fitness journal.",
      },
      { property: "og:title", content: "IRONCLAD — Premium Fitness Club" },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: Landing,
});

const nav = [
  { label: "Membership", href: "#membership" },
  { label: "BMI", href: "#bmi" },
  { label: "Training", href: "#gallery" },
  { label: "Transformations", href: "#transformations" },
  { label: "Journal", href: "#journal" },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Toaster theme="dark" position="top-center" />
      <Header />
      <Hero />
      <Marquee />
      <Pillars />
      <Membership />
      <BMI />
      <Gallery />
      <Transformations />
      <Journal />
      <CTA />
      <Footer />
    </div>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed top-0 z-50 w-full border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="container-wide flex h-16 items-center justify-between">
        <a href="#" className="flex items-center gap-2 font-display text-xl tracking-widest">
          <span className="inline-block size-2 bg-primary" />
          IRONCLAD
        </a>
        <nav className="hidden items-center gap-8 lg:flex">
          {nav.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
            >
              {n.label}
            </a>
          ))}
        </nav>
        <a href="#membership" className="btn-primary hidden lg:inline-flex">
          Join Now <ArrowRight className="size-4" />
        </a>
        <button
          aria-label="Menu"
          onClick={() => setOpen(!open)}
          className="lg:hidden p-2 text-foreground"
        >
          <Menu className="size-5" />
        </button>
      </div>
      {open && (
        <div className="border-t border-border bg-background lg:hidden">
          <div className="container-wide flex flex-col gap-4 py-4">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground"
              >
                {n.label}
              </a>
            ))}
            <a href="#membership" onClick={() => setOpen(false)} className="btn-primary">
              Join Now
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section className="relative isolate flex min-h-[100svh] items-end overflow-hidden pt-16">
      <img
        src={hero}
        alt="Athlete lifting in dark gym"
        width={1920}
        height={1080}
        className="absolute inset-0 -z-10 size-full object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-background via-background/70 to-background/20" />
      <div className="absolute inset-0 -z-10 noise-bg opacity-60" />
      <div className="container-wide grid w-full gap-10 pb-20 lg:grid-cols-[1.4fr_1fr] lg:items-end lg:pb-28">
        <div>
          <span className="eyebrow mb-6">Est. 2014 — Performance Club</span>
          <h1 className="text-[clamp(3rem,9vw,9rem)] font-black tracking-tight text-foreground">
            Train without
            <br />
            <span className="text-primary">compromise.</span>
          </h1>
          <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            A members-only training environment built for serious athletes, ambitious
            beginners, and everyone who refuses to settle for average.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <a href="#membership" className="btn-primary">
              Become a Member <ArrowRight className="size-4" />
            </a>
            <a href="#bmi" className="btn-ghost">
              Calculate Your BMI
            </a>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-6 border-t border-border pt-8 lg:border-l lg:border-t-0 lg:pl-10 lg:pt-0">
          {[
            { v: "12K+", l: "Members" },
            { v: "48", l: "Coaches" },
            { v: "9.8", l: "Avg Rating" },
          ].map((s) => (
            <div key={s.l}>
              <div className="font-display text-3xl text-primary sm:text-5xl">{s.v}</div>
              <div className="mt-1 text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                {s.l}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = ["Strength", "Conditioning", "Hypertrophy", "Mobility", "Endurance", "Recovery"];
  return (
    <div className="border-y border-border bg-surface overflow-hidden">
      <div className="flex animate-[scroll_30s_linear_infinite] gap-12 whitespace-nowrap py-5">
        {[...items, ...items, ...items].map((it, i) => (
          <span
            key={i}
            className="flex items-center gap-12 font-display text-2xl uppercase tracking-widest text-muted-foreground"
          >
            {it}
            <span className="size-1.5 rounded-full bg-primary" />
          </span>
        ))}
      </div>
      <style>{`@keyframes scroll{from{transform:translateX(0)}to{transform:translateX(-33.33%)}}`}</style>
    </div>
  );
}

function Pillars() {
  const pillars = [
    { icon: Dumbbell, t: "Strength", d: "Programmed periodization built around your goals — not generic plans." },
    { icon: Flame, t: "Conditioning", d: "High-output sessions calibrated for fat loss and athletic capacity." },
    { icon: Heart, t: "Recovery", d: "Cold plunge, infrared sauna, mobility studio and recovery lounges." },
    { icon: Zap, t: "Coaching", d: "1:1 access to certified S&C coaches, nutritionists, and physios." },
  ];
  return (
    <section className="container-wide py-24 lg:py-32">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.5fr] lg:items-end">
        <div>
          <span className="eyebrow mb-6">What We Do</span>
          <h2 className="text-5xl font-black lg:text-7xl">
            Four pillars.<br />One method.
          </h2>
        </div>
        <p className="text-base text-muted-foreground lg:text-lg">
          We don't sell access to machines. We sell results — built on a methodology
          refined across a decade of working with national athletes, executives, and
          people training to become their strongest version.
        </p>
      </div>
      <div className="mt-16 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
        {pillars.map((p) => (
          <div key={p.t} className="group bg-background p-8 transition-colors hover:bg-surface">
            <p.icon className="size-8 text-primary" />
            <h3 className="mt-8 text-2xl">{p.t}</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Membership() {
  const plans = [
    {
      name: "Pulse",
      price: 49,
      tag: "Off-peak access",
      perks: ["Off-peak gym floor access", "Group class library", "App workouts", "Locker access"],
    },
    {
      name: "Forge",
      price: 99,
      featured: true,
      tag: "Most popular",
      perks: [
        "Unlimited 24/7 access",
        "All classes — strength, HIIT, mobility",
        "Recovery suite (sauna, plunge)",
        "Monthly InBody scan",
        "Personal program in-app",
      ],
    },
    {
      name: "Apex",
      price: 199,
      tag: "Coached programme",
      perks: [
        "Everything in Forge",
        "Weekly 1:1 coaching",
        "Nutrition consultations",
        "Physio + mobility sessions",
        "Guest passes monthly",
      ],
    },
  ];
  const [plan, setPlan] = useState("Forge");
  const [form, setForm] = useState({ name: "", email: "", phone: "" });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email) return toast.error("Please fill in name and email");
    toast.success(`Welcome, ${form.name.split(" ")[0]}! Your ${plan} membership is reserved.`);
    setForm({ name: "", email: "", phone: "" });
  };

  return (
    <section id="membership" className="border-y border-border bg-surface py-24 lg:py-32">
      <div className="container-wide">
        <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-end">
          <div>
            <span className="eyebrow mb-6">Membership</span>
            <h2 className="text-5xl font-black lg:text-7xl">
              Choose your<br />training tier.
            </h2>
          </div>
          <p className="max-w-md text-muted-foreground">
            Cancel any time. All tiers include the IRONCLAD app, member events, and
            access to our training journal.
          </p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {plans.map((p) => (
            <button
              key={p.name}
              onClick={() => setPlan(p.name)}
              className={`group flex flex-col border bg-background p-8 text-left transition-all ${
                plan === p.name
                  ? "border-primary shadow-[0_0_0_1px_var(--color-primary)]"
                  : "border-border hover:border-foreground/30"
              } ${p.featured ? "lg:scale-[1.02]" : ""}`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-3xl">{p.name}</h3>
                {p.featured && (
                  <span className="bg-primary px-2 py-1 text-[0.6rem] font-bold uppercase tracking-widest text-primary-foreground">
                    Popular
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                {p.tag}
              </div>
              <div className="mt-8 flex items-baseline gap-2">
                <span className="font-display text-6xl text-primary">${p.price}</span>
                <span className="text-sm text-muted-foreground">/ month</span>
              </div>
              <ul className="mt-8 space-y-3 border-t border-border pt-6">
                {p.perks.map((perk) => (
                  <li key={perk} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <Check className="mt-0.5 size-4 shrink-0 text-primary" />
                    {perk}
                  </li>
                ))}
              </ul>
              <div className="mt-8 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest">
                {plan === p.name ? (
                  <span className="text-primary">Selected</span>
                ) : (
                  <span className="text-muted-foreground">Select Plan</span>
                )}
              </div>
            </button>
          ))}
        </div>

        <form
          onSubmit={submit}
          className="mt-12 grid gap-4 border border-border bg-background p-6 sm:p-10 lg:grid-cols-[1fr_1fr_1fr_auto] lg:items-end"
        >
          <Field
            label="Full Name"
            value={form.name}
            onChange={(v) => setForm({ ...form, name: v })}
            placeholder="Alex Morgan"
          />
          <Field
            label="Email"
            type="email"
            value={form.email}
            onChange={(v) => setForm({ ...form, email: v })}
            placeholder="you@email.com"
          />
          <Field
            label="Phone"
            value={form.phone}
            onChange={(v) => setForm({ ...form, phone: v })}
            placeholder="+1 555 0000"
          />
          <button type="submit" className="btn-primary h-[52px]">
            Reserve {plan} <ArrowRight className="size-4" />
          </button>
        </form>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-[52px] w-full border border-border bg-surface px-4 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary"
      />
    </label>
  );
}

function BMI() {
  const [unit, setUnit] = useState<"metric" | "imperial">("metric");
  const [h, setH] = useState(175);
  const [w, setW] = useState(72);

  const bmi = useMemo(() => {
    if (!h || !w) return 0;
    if (unit === "metric") return w / (h / 100) ** 2;
    return (w / (h * h)) * 703;
  }, [h, w, unit]);

  const category = useMemo(() => {
    if (bmi < 18.5) return { name: "Underweight", color: "oklch(0.7 0.18 220)" };
    if (bmi < 25) return { name: "Optimal Range", color: "var(--color-primary)" };
    if (bmi < 30) return { name: "Overweight", color: "oklch(0.78 0.18 70)" };
    return { name: "Obese", color: "oklch(0.65 0.24 27)" };
  }, [bmi]);

  const pct = Math.min(100, Math.max(0, ((bmi - 15) / (40 - 15)) * 100));

  return (
    <section id="bmi" className="container-wide py-24 lg:py-32">
      <div className="grid gap-16 lg:grid-cols-[1fr_1.4fr] lg:items-center">
        <div>
          <span className="eyebrow mb-6">Diagnostic</span>
          <h2 className="text-5xl font-black lg:text-7xl">
            Know your<br />starting line.
          </h2>
          <p className="mt-6 max-w-md text-muted-foreground">
            Body Mass Index is a directional benchmark — not the full picture. Use it
            as a starting point, then book an InBody scan with one of our coaches for
            real composition data.
          </p>
        </div>

        <div className="border border-border bg-surface p-6 sm:p-10">
          <div className="mb-6 inline-flex border border-border">
            {(["metric", "imperial"] as const).map((u) => (
              <button
                key={u}
                onClick={() => {
                  setUnit(u);
                  if (u === "imperial") {
                    setH(69);
                    setW(159);
                  } else {
                    setH(175);
                    setW(72);
                  }
                }}
                className={`px-5 py-2 text-xs font-semibold uppercase tracking-widest transition-colors ${
                  unit === u ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {u}
              </button>
            ))}
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <NumberInput
              label={`Height (${unit === "metric" ? "cm" : "in"})`}
              value={h}
              setValue={setH}
              min={unit === "metric" ? 120 : 48}
              max={unit === "metric" ? 230 : 90}
            />
            <NumberInput
              label={`Weight (${unit === "metric" ? "kg" : "lb"})`}
              value={w}
              setValue={setW}
              min={unit === "metric" ? 30 : 66}
              max={unit === "metric" ? 200 : 440}
            />
          </div>

          <div className="mt-10 border-t border-border pt-8">
            <div className="flex items-end justify-between">
              <div>
                <div className="text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                  Your BMI
                </div>
                <div className="font-display text-7xl text-primary">{bmi.toFixed(1)}</div>
              </div>
              <div className="text-right">
                <div className="text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                  Category
                </div>
                <div
                  className="mt-1 font-display text-2xl"
                  style={{ color: category.color }}
                >
                  {category.name}
                </div>
              </div>
            </div>

            <div className="mt-6 h-2 w-full bg-background">
              <div
                className="h-full transition-all"
                style={{ width: `${pct}%`, background: "var(--color-primary)" }}
              />
            </div>
            <div className="mt-2 flex justify-between text-[0.65rem] uppercase tracking-widest text-muted-foreground">
              <span>15</span>
              <span>18.5</span>
              <span>25</span>
              <span>30</span>
              <span>40</span>
            </div>

            <a href="#membership" className="btn-primary mt-8 w-full">
              Get a coached plan <ArrowRight className="size-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function NumberInput({
  label,
  value,
  setValue,
  min,
  max,
}: {
  label: string;
  value: number;
  setValue: (n: number) => void;
  min: number;
  max: number;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
        {label}
      </span>
      <input
        type="number"
        value={value}
        min={min}
        max={max}
        onChange={(e) => setValue(Number(e.target.value))}
        className="h-[52px] w-full border border-border bg-background px-4 font-display text-2xl text-foreground outline-none transition-colors focus:border-primary"
      />
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => setValue(Number(e.target.value))}
        className="mt-3 w-full accent-[var(--color-primary)]"
      />
    </label>
  );
}

function Gallery() {
  const items = [
    { src: w1, t: "Power Endurance", cat: "Conditioning" },
    { src: w2, t: "Heavy Pulls", cat: "Strength" },
    { src: w3, t: "Combat Conditioning", cat: "Boxing" },
    { src: w4, t: "Kettlebell Flow", cat: "Hybrid" },
    { src: w5, t: "Mobility Studio", cat: "Recovery" },
    { src: w6, t: "Sprint Lab", cat: "Track" },
  ];
  return (
    <section id="gallery" className="border-t border-border bg-surface py-24 lg:py-32">
      <div className="container-wide">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="eyebrow mb-6">Inside The Gym</span>
            <h2 className="text-5xl font-black lg:text-7xl">
              Workout<br />Gallery
            </h2>
          </div>
          <p className="max-w-sm text-muted-foreground">
            A peek at the floor — programmed sessions across strength, conditioning,
            combat, and recovery. New classes weekly.
          </p>
        </div>

        <div className="mt-14 grid auto-rows-[280px] gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:auto-rows-[320px]">
          {items.map((it, i) => (
            <a
              key={it.t}
              href="#membership"
              className={`group relative block overflow-hidden bg-background ${
                i === 0 ? "lg:col-span-2 lg:row-span-2" : ""
              } ${i === 3 ? "lg:col-span-2" : ""}`}
            >
              <img
                src={it.src}
                alt={it.t}
                loading="lazy"
                className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <div className="text-[0.65rem] uppercase tracking-[0.2em] text-primary">
                  {it.cat}
                </div>
                <div className="mt-1 font-display text-2xl">{it.t}</div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Transformations() {
  const stories = [
    {
      img: t1,
      name: "Marcus T.",
      stat: "-18 kg · 22 weeks",
      quote: "I stopped chasing motivation. The structure here made it automatic.",
    },
    {
      img: t2,
      name: "Lena R.",
      stat: "-12 kg · 16 weeks",
      quote: "First time in my life I trained without dreading it. Real coaching changes everything.",
    },
    {
      img: t3,
      name: "Daniel K.",
      stat: "+9 kg lean · 9 months",
      quote: "Went from skinny-fat to deadlifting twice my bodyweight. Methodical, not magic.",
    },
  ];
  return (
    <section id="transformations" className="container-wide py-24 lg:py-32">
      <div className="grid gap-10 lg:grid-cols-[1fr_2fr] lg:items-end">
        <div>
          <span className="eyebrow mb-6">Real Results</span>
          <h2 className="text-5xl font-black lg:text-7xl">
            Members who<br />did the work.
          </h2>
        </div>
        <p className="max-w-md text-muted-foreground lg:justify-self-end">
          Not influencers. Not edits. Photos and timelines from members training in
          the room next to you. With permission, of course.
        </p>
      </div>

      <div className="mt-14 grid gap-6 lg:grid-cols-3">
        {stories.map((s) => (
          <article key={s.name} className="group border border-border bg-surface">
            <div className="relative aspect-[4/5] overflow-hidden">
              <img
                src={s.img}
                alt={`Transformation — ${s.name}`}
                loading="lazy"
                className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute left-4 top-4 bg-primary px-2 py-1 text-[0.6rem] font-bold uppercase tracking-widest text-primary-foreground">
                {s.stat}
              </div>
            </div>
            <div className="p-6">
              <Quote className="size-5 text-primary" />
              <p className="mt-3 text-sm leading-relaxed text-foreground">"{s.quote}"</p>
              <div className="mt-4 text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                — {s.name}, Forge Member
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Journal() {
  const posts = [
    {
      img: b1,
      cat: "Nutrition",
      title: "The protein math 90% of lifters get wrong",
      read: "6 min read",
    },
    {
      img: b2,
      cat: "Strength",
      title: "Why your deadlift stalled at intermediate weights",
      read: "8 min read",
    },
    {
      img: b3,
      cat: "Recovery",
      title: "Sleep is the steroid you're not taking",
      read: "5 min read",
    },
  ];
  return (
    <section id="journal" className="border-t border-border bg-surface py-24 lg:py-32">
      <div className="container-wide">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="eyebrow mb-6">The Journal</span>
            <h2 className="text-5xl font-black lg:text-7xl">
              Read.<br />Then train.
            </h2>
          </div>
          <a href="#" className="btn-ghost">
            All Articles <ArrowRight className="size-4" />
          </a>
        </div>

        <div className="mt-14 grid gap-px bg-border lg:grid-cols-3">
          {posts.map((p) => (
            <a
              key={p.title}
              href="#"
              className="group flex flex-col bg-background transition-colors hover:bg-surface-2"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={p.img}
                  alt={p.title}
                  loading="lazy"
                  className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <div className="flex flex-1 flex-col p-6">
                <div className="flex items-center justify-between text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                  <span className="text-primary">{p.cat}</span>
                  <span>{p.read}</span>
                </div>
                <h3 className="mt-4 text-2xl leading-tight transition-colors group-hover:text-primary">
                  {p.title}
                </h3>
                <span className="mt-6 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-primary">
                  Read article <ArrowRight className="size-3" />
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="container-wide py-24 lg:py-32">
      <div className="relative isolate overflow-hidden border border-border bg-background p-10 sm:p-16 lg:p-24">
        <div className="absolute inset-0 -z-10 noise-bg opacity-50" />
        <div className="absolute -right-20 -top-20 -z-10 size-[400px] rounded-full bg-primary/20 blur-3xl" />
        <span className="eyebrow mb-8">Limited Spots</span>
        <h2 className="text-5xl font-black lg:text-8xl">
          Stop training<br />
          <span className="text-primary">to feel busy.</span>
        </h2>
        <p className="mt-6 max-w-xl text-muted-foreground">
          Start training to win. Memberships open monthly with a hard cap. Reserve
          your spot before the next intake closes.
        </p>
        <div className="mt-10 flex flex-wrap gap-4">
          <a href="#membership" className="btn-primary">
            Reserve Membership <ArrowRight className="size-4" />
          </a>
          <a href="#bmi" className="btn-ghost">
            Try the Tools
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-surface">
      <div className="container-wide grid gap-12 py-16 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-display text-xl tracking-widest">
            <span className="inline-block size-2 bg-primary" />
            IRONCLAD
          </div>
          <p className="mt-4 text-sm text-muted-foreground">
            Premium fitness, performance coaching, and recovery — in one members-only
            address.
          </p>
        </div>
        {[
          { h: "Club", l: ["Membership", "Locations", "Recovery", "Classes"] },
          { h: "Resources", l: ["BMI Tool", "Journal", "Transformations", "FAQ"] },
          { h: "Contact", l: ["hello@ironclad.gym", "+1 (555) 010-2024", "Open 24/7"] },
        ].map((c) => (
          <div key={c.h}>
            <div className="text-[0.65rem] font-semibold uppercase tracking-[0.25em] text-primary">
              {c.h}
            </div>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              {c.l.map((x) => (
                <li key={x}>{x}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-border">
        <div className="container-wide flex flex-col items-center justify-between gap-4 py-6 text-xs uppercase tracking-widest text-muted-foreground sm:flex-row">
          <span>© {new Date().getFullYear()} Ironclad Performance Club</span>
          <div className="flex items-center gap-4">
            <a href="#" aria-label="Instagram" className="hover:text-primary">
              <Instagram className="size-4" />
            </a>
            <a href="#" aria-label="Twitter" className="hover:text-primary">
              <Twitter className="size-4" />
            </a>
            <a href="#" aria-label="YouTube" className="hover:text-primary">
              <Youtube className="size-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
